package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashMap;
import java.util.Map;

/** Árvores e habilidades definidas pelos OPs (salvas no mundo). As árvores reutilizam QuestTabDef. */
public class SkillData extends SavedData {
    public final Map<String, QuestTabDef> trees = new LinkedHashMap<>();
    public final Map<String, SkillDef> skills = new LinkedHashMap<>();

    public static SkillData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(SkillData::load, SkillData::createDefault, "classselector_skills");
    }

    private static SkillDef skill(String id, String parent, String name, String desc, String icon,
                                  int cost, int reward, ItemStack... items) {
        SkillDef s = new SkillDef();
        s.id = id; s.tree = "geral"; s.parent = parent; s.name = name; s.description = desc; s.icon = icon;
        s.xpCost = cost; s.xpReward = reward;
        for (ItemStack i : items) s.rewards.add(i);
        return s;
    }

    private static SkillData createDefault() {
        SkillData d = new SkillData();
        QuestTabDef t = new QuestTabDef();
        t.id = "geral"; t.name = "Geral"; t.icon = "minecraft:nether_star";
        d.trees.put(t.id, t);
        SkillDef[] list = {
            skill("despertar", "", "Despertar", "Primeiro passo da sua jornada.",
                    "minecraft:experience_bottle", 1, 0, new ItemStack(Items.BREAD, 8)),
            skill("aprendiz", "despertar", "Aprendiz", "Reforça seu equipamento.",
                    "minecraft:iron_ingot", 3, 0, new ItemStack(Items.IRON_INGOT, 5)),
            skill("mestre", "aprendiz", "Mestre", "O topo da árvore.",
                    "minecraft:diamond", 5, 2, new ItemStack(Items.DIAMOND, 2)),
        };
        for (SkillDef s : list) d.skills.put(s.id, s);
        d.setDirty();
        return d;
    }

    public static SkillData load(CompoundTag tag) {
        SkillData d = new SkillData();
        for (Tag t : tag.getList("trees", Tag.TAG_COMPOUND)) {
            QuestTabDef x = QuestTabDef.load((CompoundTag) t);
            if (!x.id.isEmpty()) d.trees.put(x.id, x);
        }
        for (Tag t : tag.getList("skills", Tag.TAG_COMPOUND)) {
            SkillDef x = SkillDef.load((CompoundTag) t);
            if (!x.id.isEmpty()) d.skills.put(x.id, x);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag tl = new ListTag();
        for (QuestTabDef t : trees.values()) tl.add(t.save());
        tag.put("trees", tl);
        ListTag sl = new ListTag();
        for (SkillDef s : skills.values()) sl.add(s.save());
        tag.put("skills", sl);
        return tag;
    }
}
