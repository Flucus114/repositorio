package com.classselector;

import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.EnchantmentMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.enchanting.EnchantmentLevelSetEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class ServerEvents {
    private static final int MAX_ENCHANT_LEVEL = 30;

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        RaceApplier.refresh(p);
        Net.sendSync(p, Net.initialOpen(p));
    }

    /** Mantém raça e classe depois de morrer e reaplica os bônus de raça. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var from = e.getOriginal().getPersistentData();
        var to = e.getEntity().getPersistentData();
        for (String key : new String[]{ClassSelectorMod.KEY, ClassSelectorMod.KEY_RACE}) {
            String s = from.getString(key);
            if (!s.isEmpty()) to.putString(key, s);
        }
        if (e.getEntity() instanceof ServerPlayer p) RaceApplier.refresh(p);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            RaceApplier.refresh(p);
            Net.sendSync(p, 0);
        }
    }

    /** Velocidade de mineração da raça (roda no cliente e no servidor). */
    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        RaceDef r = RaceLookup.of(e.getEntity());
        if (r != null && r.miningPct != 0) {
            e.setNewSpeed(e.getNewSpeed() * (float) Math.max(0.0, 1.0 + r.miningPct / 100.0));
        }
    }

    /** Vantagem na mesa de encantamento: soma níveis de poder ao nível oferecido. */
    @SubscribeEvent
    public static void onEnchantLevel(EnchantmentLevelSetEvent e) {
        Level lv = e.getLevel();
        if (lv.isClientSide || e.getEnchantLevel() <= 0) return;
        Vec3 center = Vec3.atCenterOf(e.getPos());
        Player best = null;
        double bestD = 100;
        for (Player p : lv.players()) {
            if (p.containerMenu instanceof EnchantmentMenu) {
                double d = p.distanceToSqr(center);
                if (d < bestD) { bestD = d; best = p; }
            }
        }
        if (best == null) return;
        RaceDef r = RaceLookup.of(best);
        if (r == null || r.enchant == 0) return;
        int min = e.getEnchantRow() + 1;
        e.setEnchantLevel(Mth.clamp(e.getEnchantLevel() + r.enchant, min, Math.max(min, MAX_ENCHANT_LEVEL)));
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("classes")
                .requires(s -> s.hasPermission(2))
                // /classes -> tela de classes (com botões de OP)
                .executes(c -> {
                    Net.sendSync(c.getSource().getPlayerOrException(), 1);
                    return 1;
                })
                // /classes races -> tela de raças (com botões de OP)
                .then(Commands.literal("races").executes(c -> {
                    Net.sendSync(c.getSource().getPlayerOrException(), 3);
                    return 1;
                }))
                // /classes reset <jogador> -> jogador escolhe raça e classe de novo
                .then(Commands.literal("reset").then(Commands.argument("player", EntityArgument.player())
                        .executes(c -> {
                            ServerPlayer t = EntityArgument.getPlayer(c, "player");
                            t.getPersistentData().remove(ClassSelectorMod.KEY);
                            t.getPersistentData().remove(ClassSelectorMod.KEY_RACE);
                            RaceApplier.refresh(t);
                            QuestManager.sync(t, false);
                            SkillManager.sync(t, false);
                            Net.sendSync(t, Net.initialOpen(t));
                            c.getSource().sendSuccess(() -> Component.literal(
                                    "Raça e classe de " + t.getName().getString() + " resetadas."), true);
                            return 1;
                        }))));
    }
}
