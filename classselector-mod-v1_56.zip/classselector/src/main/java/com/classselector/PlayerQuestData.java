package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Progresso de quests de cada jogador. */
public class PlayerQuestData extends SavedData {
    public static class PQ {
        public final Map<String, Integer> progress = new HashMap<>();
        public final Set<String> done = new HashSet<>();
    }

    public final Map<UUID, PQ> players = new HashMap<>();

    public static PlayerQuestData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(PlayerQuestData::load, PlayerQuestData::new, "classselector_quest_progress");
    }

    public PQ of(UUID id) { return players.computeIfAbsent(id, k -> new PQ()); }

    public static PlayerQuestData load(CompoundTag tag) {
        PlayerQuestData d = new PlayerQuestData();
        for (Tag t : tag.getList("players", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            UUID id;
            try { id = UUID.fromString(c.getString("uuid")); } catch (Exception e) { continue; }
            PQ pq = d.of(id);
            CompoundTag pr = c.getCompound("progress");
            for (String k : pr.getAllKeys()) pq.progress.put(k, pr.getInt(k));
            for (Tag s : c.getList("done", Tag.TAG_STRING)) pq.done.add(s.getAsString());
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (Map.Entry<UUID, PQ> e : players.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putString("uuid", e.getKey().toString());
            CompoundTag pr = new CompoundTag();
            for (Map.Entry<String, Integer> p : e.getValue().progress.entrySet()) pr.putInt(p.getKey(), p.getValue());
            c.put("progress", pr);
            ListTag dl = new ListTag();
            for (String s : e.getValue().done) dl.add(StringTag.valueOf(s));
            c.put("done", dl);
            l.add(c);
        }
        tag.put("players", l);
        return tag;
    }
}
